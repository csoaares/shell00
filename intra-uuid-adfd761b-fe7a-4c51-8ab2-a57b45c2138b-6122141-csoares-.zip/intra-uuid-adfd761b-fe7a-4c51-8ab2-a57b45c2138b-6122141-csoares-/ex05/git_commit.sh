git log --format='%H' -n5 | sed 's/$/$/'

